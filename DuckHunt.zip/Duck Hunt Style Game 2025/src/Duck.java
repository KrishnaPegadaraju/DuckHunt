import java.awt.*;
import java.awt.geom.AffineTransform;
import java.net.URL;

public class Duck {
    public boolean flyAway2 = false;
    public boolean falling = false;
    public Image img;
    private AffineTransform tx;
    public double scaleX, scaleY, x, y;
    public int vx, vy;
    private int fallTimer = 0;

    public Duck() {
        img = getImage("imgs/Bat (1).gif");
        tx = AffineTransform.getTranslateInstance(0, 0);
        scaleX = 0.5;
        scaleY = 0.5;

        // Random spawn position
        x = (int)(Math.random() * 500) + 100;
        y = (int)(Math.random() * 400) + 100;

        // Random speed and direction
        vx = (int)(Math.random() * 20) + 5; 
        vy = (int)(Math.random() * 10) + 2;
        
        if (Math.random() < 0.5) {
        	vx *= -1;
        }
        
        if (Math.random() < 0.5) {
        	vy *= -1;
        }

        init(x, y);
    }

    public void setVelocityVariables(int vx, int vy) {
        this.vx = vx;
        this.vy = vy;
    }

    public void update() {
        x += vx;
        y += vy;

        // Bounce off proper screen borders
        if (!flyAway2 && !falling) {
            if (x >= 610 || x <= -210) vx *= -1;
            if (y >= 610 || y <= -210) vy *= -1;
        }

        
        
        
        // Fly-away behavior
        if (flyAway2 && y < -100) {
            flyAway2 = false;
            Frame.flyAway = false;
            respawn();
            Frame.ammo = 3;
        }

        // Falling behavior
        if (falling) {
            fallTimer++;
            if (y < 800) vy = 40;
            else vy = 0;

            if (fallTimer > 60) {
                falling = false;
                fallTimer = 0;
                respawn();
                Frame.ammo = 3;
            }
        }
    }

    public void respawn() {
        // Random new position
        x = (int)(Math.random() * 500) + 100;
        y = (int)(Math.random() * 400) + 100;

        // Random new speed + direction
        vx = (int)(Math.random() * 20) + 20;
        vy = (int)(Math.random() * 10) + 10;
        if (Math.random() < 0.5) vx *= -1;
        if (Math.random() < 0.5) vy *= -1;

        falling = false;
        flyAway2 = false;
    }

    public void paint(Graphics g) {
        Graphics2D g2 = (Graphics2D) g;
        g2.drawImage(img, tx, null);
        update();
        init(x, y);
    }

    private void init(double a, double b) {
        tx.setToTranslation(a, b);
        tx.scale(scaleX, scaleY);
    }

    private Image getImage(String path) {
        Image tempImage = null;
        try {
            URL imageURL = Duck.class.getResource(path);
            if (imageURL == null) {
                tempImage = Toolkit.getDefaultToolkit().getImage(path);
            } else {
                tempImage = Toolkit.getDefaultToolkit().getImage(imageURL);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return tempImage;
    }

    public boolean checkCollision(int mouseX, int mouseY) {
        Rectangle mouse = new Rectangle(mouseX, mouseY, 1, 1);
        Rectangle hitbox = new Rectangle((int)x + 150, (int)y + 180, 150, 100);

        if (mouse.intersects(hitbox)) {
            vx = 0;
            vy = 40;
            falling = true;
            fallTimer = 0;
            return true;
        } else {
            return false;
            
        }
    }
    
    
    public double getY() {
        return y;
    }

}
