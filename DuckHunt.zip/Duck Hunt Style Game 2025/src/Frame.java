import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Frame extends JPanel implements ActionListener, MouseListener, KeyListener {

    public static int ammo = 3;
    private int score = 0;
    private int hitsInWave = 0;
    private int wave = 1;
    public static boolean flyAway = false;

    private int screenWidth = 900, screenHeight = 900;
    private String title = "Bat Bash";

    private Music mouseClickSound = new Music("sfx_wpn_laser9.wav", false);
    private Music flyAwaySound = new Music("fly_away.wav.wav", false);
    private Music hitSound = new Music("hit.wav", false);
    private Music waveCompleteSound = new Music("next_wave.wav", false);


    public  Duck duckObject = new Duck();
    private Background1 myBackground1 = new Background1();
    private Background2 myBackground2 = new Background2();
    private zombieHand zombieHand = new zombieHand();

    private Timer timer;

    public Frame() {
        JFrame f = new JFrame(title);
        f.setSize(new Dimension(screenWidth, screenHeight));
        f.setBackground(Color.blue);
        f.add(this);
        f.setResizable(false);
        f.setLayout(new GridLayout(1, 1));
        this.addMouseListener(this);
        f.addKeyListener(this);

        timer = new Timer(16, this);
        timer.start();

        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setVisible(true);

        Toolkit toolkit = Toolkit.getDefaultToolkit();
        Image image = toolkit.getImage("CrossHairr.png");
        Cursor a = toolkit.createCustomCursor(image, new Point(this.getX(), this.getY()), "Crosshair");
        this.setCursor(a);
    }

    @Override
    public void paint(Graphics pen) {
        super.paintComponent(pen);
        myBackground1.paint(pen);
        myBackground2.paint(pen);
        duckObject.paint(pen);
        zombieHand.paint(pen);

        Font bigFont = new Font("Serif", Font.BOLD, 70);
        pen.setColor(Color.black);
        pen.setFont(bigFont);
        pen.drawString("Ammo: " + ammo, 100, 75);
        pen.drawString("Score: " + score, 500, 75);
        pen.drawString("Wave: " + wave, 300, 800);

        if (flyAway) {
            pen.setColor(Color.red);
            pen.setFont(new Font("Serif", Font.BOLD, 80));
            pen.drawString("You lost the bat!", 150, 400);
        }
    }

    @Override
    public void mousePressed(MouseEvent mouse) {
        mouseClickSound.play();
        if (flyAway) return;

        boolean hit = duckObject.checkCollision(mouse.getX(), mouse.getY());
        ammo--;

        // if hit
        if (hit) {
            score++;
            hitsInWave++;
            ammo = 3;
            hitSound.play();
        }

        // every 5 waves there is a fanfare played
        if (hit && hitsInWave % 5 == 0) {

        	wave++;
            waveCompleteSound.play();
        }
        // if it isn't hitting the duck and the ammo is less than 0 make duck fly away and play laughing sound
        if (!hit && ammo == 0) {
            flyAway = true;
            duckObject.flyAway2 = true;
            flyAwaySound.play();

            int direction = Math.random() < 0.5 ? -8 : 8;
            duckObject.setVelocityVariables(direction, -15);
        }
    }




    @Override
    public void actionPerformed(ActionEvent e) {
        // When the bat actually leaves the screen (y < -200)
        if (flyAway && duckObject.y < -200) {
            // Keep flyAway true for one more frame so the hand rises
            flyAway = true;
        } else if (!flyAway && duckObject.y >= -200) {
            // Once the bat respawns, hand will go back down
            flyAway = false;
        }

        repaint();
    }


    public void mouseClicked(MouseEvent e) {
    	
    }
    public void mouseReleased(MouseEvent e) {
    	
    }
    public void mouseEntered(MouseEvent e) {
    
    }
    public void mouseExited(MouseEvent e) {}
    public void keyTyped(KeyEvent e) {}
    public void keyPressed(KeyEvent e) {}
    public void keyReleased(KeyEvent e) {}

    public static void main(String[] args) {
        new Frame();
    }
}
